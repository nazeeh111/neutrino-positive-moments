# Exact endpoint witness: portable native replay

This small archive replays one already documented mathematical example, not a new theorem or astrophysical measurement. Extract into a fresh directory; Python 3 standard library is sufficient. Run:

    python3 -I -S -B -O check.py
    python3 -I -S -B kernel/finite_band_envelope.py --mass 1 --second 1/3 --kmax 1/1000

case.json stores four positive atoms and source hashes. evaluator.json is native output; checked.json records the delivered replay. check.py checks every payload hash, the three exact original kernel modules, moment equality, the native evaluator and zero of the original longitudinal factor. It also rejects altered weights/growth. No scientific package, installation, network request, optimizer or scan is needed. Checks write no output files. Hashes require trusted local code and identify bytes, not authorship.

index.html is an offline readable case. For HTTP use an owned available port: python3 -m http.server 8080 --bind 127.0.0.1, then open /index.html. The table and text remain usable without scripts; there are no scripts or external fonts. README.md is this archive-specific guide. Research proofs, tests and the full project guide are external to this subset; use the pinned source below. figure.py regenerates the two editable SVGs from case.json with only the standard library; delivered PNGs were rendered in Chrome. PHYSICAL_SCOPE.md and LICENSE retain original notices.

Both species have number moments (1,0,1/3). At reduced k=1/1000, squared growth is exactly 1333/3000000. The rational enclosure is not a confidence interval. Positivity and this zero prove one completion attains the stated result; the universal upper bound relies on the written proof. No physical wavelength/time, universal instability, smooth/occupation-constrained attainment, scientific priority or practical astrophysical advantage is established. The paper remains a working draft dated 2 November 2026, not submitted or peer reviewed. No research PDF or historical data is replaced.

Pinned research source and written proof:
https://github.com/nazeeh111/neutrino-positive-moments/tree/27d997295b478f6e214df0d92b49fb5117ec8c8d
https://github.com/nazeeh111/neutrino-positive-moments/blob/27d997295b478f6e214df0d92b49fb5117ec8c8d/finite-k-transition-audit.md
